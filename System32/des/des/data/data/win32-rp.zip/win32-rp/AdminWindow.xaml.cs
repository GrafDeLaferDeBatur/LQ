﻿using System.Windows;

namespace Win32
{
    /// <summary>
    /// Логика взаимодействия для AdminWindow.xaml
    /// </summary>
    public partial class AdminWindow : Window
    {
        public AdminWindow()
        {
            InitializeComponent();
        }



        private void tables_Loaded(object sender, RoutedEventArgs e)
        {

        }
    }
}
