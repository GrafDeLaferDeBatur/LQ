﻿using System.Windows;

namespace Win32
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {

            InitializeComponent();

        }

        private void Buttons_Loaded(object sender, RoutedEventArgs e)
        {

        }


    }
}